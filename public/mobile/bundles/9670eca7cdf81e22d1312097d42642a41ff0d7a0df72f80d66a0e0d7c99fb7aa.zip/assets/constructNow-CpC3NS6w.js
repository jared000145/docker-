import{c as t}from"./fr-BTuRQBqD.js";function c(o){return t(o,Date.now())}export{c};
