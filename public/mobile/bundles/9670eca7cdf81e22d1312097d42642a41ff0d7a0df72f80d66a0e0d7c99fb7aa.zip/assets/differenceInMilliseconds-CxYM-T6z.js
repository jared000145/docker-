import{t as e}from"./fr-BTuRQBqD.js";function r(t,n){return+e(t)-+e(n)}export{r as d};
