import{p}from"./LoginPage-BN-CZC97.js";import"./index-DWYS8iEy.js";import"./proxy-DL_xragA.js";export{p as default};
