import{t as o}from"./fr-BTuRQBqD.js";function r(t){return+o(t)<Date.now()}export{r as i};
