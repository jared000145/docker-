import{f as r}from"./LoginPage-BRey35Xg.js";import"./index-BcqxgUEJ.js";import"./proxy-Cy8ElHH1.js";export{r as default};
