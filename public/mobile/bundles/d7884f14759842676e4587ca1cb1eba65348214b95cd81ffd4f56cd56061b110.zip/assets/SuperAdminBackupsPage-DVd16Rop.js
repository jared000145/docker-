import{j as e,N as r}from"./index-D2HDzF7l.js";function a(){return e.jsx(r,{to:"/super-admin/restore",replace:!0})}export{a as default};
