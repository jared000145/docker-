import{f as r}from"./LoginPage-CGqqyQsE.js";import"./index-hCuPxuv3.js";import"./proxy-RU0uGu_O.js";export{r as default};
