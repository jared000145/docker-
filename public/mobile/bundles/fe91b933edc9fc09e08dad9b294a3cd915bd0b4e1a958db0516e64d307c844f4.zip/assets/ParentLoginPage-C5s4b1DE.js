import{f as r}from"./LoginPage-6XuiunqP.js";import"./index-DRgHSlrl.js";import"./proxy-CU7l5s9G.js";export{r as default};
