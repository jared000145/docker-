const s="123456",t=()=>s;export{t as g};
