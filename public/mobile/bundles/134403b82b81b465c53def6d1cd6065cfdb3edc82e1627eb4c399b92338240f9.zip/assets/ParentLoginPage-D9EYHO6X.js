import{e as r}from"./LoginPage-C_-ZZDdh.js";import"./index-B9PpP1FM.js";import"./proxy-BxhpgNGl.js";export{r as default};
