import{e as r}from"./LoginPage-D_5CKy0l.js";import"./index-D2Fj9GLh.js";import"./proxy-D8hDmhgu.js";export{r as default};
