import{f as r}from"./LoginPage-Cp-_nxmB.js";import"./index-DNmOSx8a.js";import"./proxy-ZxNgU9Bt.js";export{r as default};
