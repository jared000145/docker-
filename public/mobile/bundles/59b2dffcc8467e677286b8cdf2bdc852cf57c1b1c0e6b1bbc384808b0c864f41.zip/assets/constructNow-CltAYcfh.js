import{c as t}from"./fr-BZOdiMBc.js";function c(o){return t(o,Date.now())}export{c};
