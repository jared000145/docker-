import{t as o}from"./fr-BZOdiMBc.js";function r(t){return+o(t)<Date.now()}export{r as i};
