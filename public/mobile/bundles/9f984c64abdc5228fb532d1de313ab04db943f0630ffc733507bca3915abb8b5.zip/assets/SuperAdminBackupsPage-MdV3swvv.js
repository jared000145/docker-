import{j as e,T as r}from"./index-DJGBgvGs.js";function a(){return e.jsx(r,{to:"/super-admin/restore",replace:!0})}export{a as default};
