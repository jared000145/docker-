import{p}from"./LoginPage-DyG0jKj0.js";import"./index-DJGBgvGs.js";import"./proxy-DQClzzN5.js";export{p as default};
